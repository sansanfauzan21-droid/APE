<?php
namespace Hamcrest;

/*
 Copyright (c) 2009 hamcrest.org
 */

class AssertionError extends \RuntimeException
{
}
